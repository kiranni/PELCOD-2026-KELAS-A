print ("Ticket Ordering")
total = 0
jumlah_tiket = 0

while True:
    jenis = input("Pilih tiket (regular/vip/vvip): ")

    if jenis == "regular":
        harga = 40000
    elif jenis == "vip"

        harga = "75000"
    elif jenis == "vvip":
        harga = 100000
    else:
        print("Tiket tidak tersedia")
        continue

    jumlah = int(input("Jumlah tiket: "))
    
total